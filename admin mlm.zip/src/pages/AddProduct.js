import React, { useEffect, useState } from "react";
import PagePath from "../components/PagePath";
import { useForm, Controller } from "react-hook-form";
import {
  Grid,
  Card,
  CardHeader,
  CardContent,
  TextField,
  Button,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Tabs,
  Tab,
  Box,
  InputLabel,
} from "@mui/material";
import { TabPanel } from "@mui/lab";

const AddProduct = () => {
  const { handleSubmit, control } = useForm();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState(0);

  const handleChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const onSubmit = (data) => {
    console.log(data); // You can handle form submission here
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://server-mlm01.blockchainboostup.com/category/",
          { method: "get" }
        );
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }
  const categories = data?.category;
  console.log(data);
  console.log(categories, "123");

  function TabPanel(props) {
    const { children, value, index } = props;

    return (
      <div hidden={value !== index}>
        {value === index && <Box p={3}>{children}</Box>}
      </div>
    );
  }
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-[10px]">Products</h2>
      <PagePath
        pathOne={"/"}
        pathTwo={"#"}
        pathOneName={"Home"}
        pathTwoName={" Products"}
        pathThreeName={"   Product details"}
      />
      <form onSubmit={handleSubmit(onSubmit)} className="mt-8">
        <Grid container spacing={2}>
          <Grid item xs={12} sm={4}>
            <Card>
              <CardHeader title="Select Categories" />

              {/* <CardContent>
                <FormGroup>
                {categories
                ?.filter(
                  (parentCategory) => parentCategory.parentCategory === null
                )
                ?.map((parentCategory) => (
                  <FormControlLabel key={parentCategory._id} control={<Checkbox />} label={parentCategory.categoryName} />
                
                    {categories
                      ?.filter(
                        (childCategory) =>
                          childCategory.parentCategory?._id ===
                          parentCategory._id
                      )
                      ?.map((childCategory) => (
                        

                            <FormGroup style={{ paddingLeft: "20px" }} key={childCategory._id}>
                              <FormControlLabel control={<Checkbox />} label={childCategory.categoryName} />
                            
                            </FormGroup>
                      ))}
                  
                ))}

              
                  
                  
                </FormGroup>
              </CardContent> */}

              <CardContent>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="WOMEN" />
                  <FormGroup style={{ paddingLeft: "20px" }}>
                    <FormControlLabel control={<Checkbox />} label="footwear" />
                    <FormControlLabel control={<Checkbox />} label="clothes" />
                    {/* Add more subcategories for MEN here */}
                  </FormGroup>
                </FormGroup>
              </CardContent>

              <CardContent>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="ELECTRONIC" />
                  <FormGroup style={{ paddingLeft: "20px" }}>
                    <FormControlLabel control={<Checkbox />} label="mobile" />
                    <FormControlLabel control={<Checkbox />} label="LCD TV" />
                    <FormControlLabel
                      control={<Checkbox />}
                      label="smart watch"
                    />
                    {/* Add more subcategories for MEN here */}
                  </FormGroup>
                </FormGroup>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={8}>
            <Card>
              <CardHeader title="Add Product" />
              <CardContent>
                <Tabs
                  variant="fullWidth"
                  value={activeTab}
                  onChange={handleChange}
                >
                  <Tab label="Product Detail" />
                  <Tab label="IMAGE" />
                  <Tab label="QTY" />
                </Tabs>
                <TabPanel value={activeTab} index={0}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_CODE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT CODE"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_NAME"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT NAME"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="MRP_PRICE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="MRP PRICE*" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="SALE_PRICE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="SALE PRICE*" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="BUSINESS_VOLUMN"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="BUSINESS VOLUMN*"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PV"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="PV" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="BOOKING_AMOUNT"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="BOOKING AMOUNT"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_DESCRIPTION"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT DESCRIPTION"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    {/* Add other input fields similarly */}
                  </Grid>
                </TabPanel>
                <TabPanel value={activeTab} index={1}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <InputLabel className="mb-1 sm:mb-2 ">
                        CHOOSE MAIN IMAGE
                      </InputLabel>
                      <TextField
                        fullWidth
                        control={control}
                        name="main_image"
                        type="file"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <InputLabel className="mb-1 sm:mb-2 ">
                        CHOOSE MORE IMAGE
                      </InputLabel>

                      <TextField
                        fullWidth
                        control={control}
                        name="more_images"
                        type="file"
                        multiple
                      />
                    </Grid>
                  </Grid>
                </TabPanel>
                <TabPanel value={activeTab} index={2}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        label="Qty"
                        fullWidth
                        control={control}
                        name="qty"
                      />
                    </Grid>
                  </Grid>
                </TabPanel>
                <Button
                  sx={{ ml: 3 }}
                  type="submit"
                  variant="contained"
                  color="primary"
                >
                  Add Product
                </Button>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
        {/* <Button type="submit" variant="contained" color="primary">
          Add Product
        </Button> */}
      </form>
    </div>
  );
};

export default AddProduct;
