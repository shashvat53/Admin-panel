import React, { useState } from "react";
import PagePath from "../components/PagePath";
import { useForm, Controller } from "react-hook-form";
import {
  Grid,
  Card,
  CardHeader,
  CardContent,
  TextField,
  Button,
  Checkbox,
  FormGroup,
  FormControlLabel,
  Tabs,
  Tab,
  Box,
  InputLabel,
} from "@mui/material";

const EditProduct = () => {
  const { handleSubmit, control } = useForm();
  const [activeTab, setActiveTab] = useState(0);

  const handleChange = (event, newValue) => {
    setActiveTab(newValue);
  };

  const onSubmit = (data) => {
    console.log(data); // You can handle form submission here
  };

  function TabPanel(props) {
    const { children, value, index } = props;

    return (
      <div hidden={value !== index}>
        {value === index && <Box p={3}>{children}</Box>}
      </div>
    );
  }
  return (
    <div>
      <h2 className="text-2xl font-semibold mb-[10px]">Edit Product</h2>
      <PagePath
        pathOne={"/"}
        pathTwo={"#"}
        pathOneName={"Home"}
        pathTwoName={" Product"}
        pathThreeName={" Edit Product"}
      />
      <form onSubmit={handleSubmit(onSubmit)} className="mt-8">
        <Grid container spacing={2}>
          <Grid item xs={12} sm={8}>
            <Card>
              <CardHeader title="Edit Product" />
              <CardContent>
                <Tabs
                  variant="fullWidth"
                  value={activeTab}
                  onChange={handleChange}
                >
                  <Tab label="Product Detail" />
                  <Tab label="IMAGE" />
                  <Tab label="QTY" />
                </Tabs>
                <TabPanel value={activeTab} index={0}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_CODE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT CODE"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_NAME"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT NAME"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="MRP_PRICE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="MRP PRICE*" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="SALE_PRICE"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="SALE PRICE*" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="BUSINESS_VOLUMN"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="BUSINESS VOLUMN*"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PV"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField {...field} label="PV" fullWidth />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="BOOKING_AMOUNT"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="BOOKING AMOUNT"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <Controller
                        name="PRODUCT_DESCRIPTION"
                        control={control}
                        defaultValue=""
                        render={({ field }) => (
                          <TextField
                            {...field}
                            label="PRODUCT DESCRIPTION"
                            fullWidth
                          />
                        )}
                      />
                    </Grid>
                    {/* Add other input fields similarly */}
                  </Grid>
                </TabPanel>
                <TabPanel value={activeTab} index={1}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <InputLabel className="mb-1 sm:mb-2 ">
                        CHOOSE MAIN IMAGE
                      </InputLabel>
                      <TextField
                        fullWidth
                        control={control}
                        name="main_image"
                        type="file"
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <InputLabel className="mb-1 sm:mb-2 ">
                        CHOOSE MORE IMAGE
                      </InputLabel>

                      <TextField
                        fullWidth
                        control={control}
                        name="more_images"
                        type="file"
                        multiple
                      />
                    </Grid>
                  </Grid>
                </TabPanel>
                <TabPanel value={activeTab} index={2}>
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <TextField
                        label="Qty"
                        fullWidth
                        control={control}
                        name="qty"
                      />
                    </Grid>
                  </Grid>
                </TabPanel>
                <Button
                  sx={{ ml: 3 }}
                  type="submit"
                  variant="contained"
                  color="primary"
                >
                  Edit Product
                </Button>
              </CardContent>
            </Card>
          </Grid>
          <Grid item xs={12} sm={4}>
            <Card>
              <CardHeader title="Select Categories" />
              <CardContent>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="MEN" />
                  <FormGroup style={{ paddingLeft: "20px" }}>
                    <FormControlLabel control={<Checkbox />} label="footwear" />
                    <FormControlLabel control={<Checkbox />} label="clothes" />
                    {/* Add more subcategories for MEN here */}
                  </FormGroup>
                </FormGroup>
              </CardContent>
              <CardContent>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="WOMEN" />
                  <FormGroup style={{ paddingLeft: "20px" }}>
                    <FormControlLabel control={<Checkbox />} label="footwear" />
                    <FormControlLabel control={<Checkbox />} label="clothes" />
                    {/* Add more subcategories for MEN here */}
                  </FormGroup>
                </FormGroup>
              </CardContent>
              <CardContent>
                <FormGroup>
                  <FormControlLabel control={<Checkbox />} label="ELECTRONIC" />
                  <FormGroup style={{ paddingLeft: "20px" }}>
                    <FormControlLabel control={<Checkbox />} label="mobile" />
                    <FormControlLabel control={<Checkbox />} label="LCD TV" />
                    <FormControlLabel
                      control={<Checkbox />}
                      label="smart watch"
                    />
                    {/* Add more subcategories for MEN here */}
                  </FormGroup>
                </FormGroup>
              </CardContent>
            </Card>
          </Grid>
        </Grid>
      </form>
    </div>
  );
};

export default EditProduct;
