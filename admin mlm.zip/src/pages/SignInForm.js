import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

const SignInForm = ({}) => {
  const [emailAddress, setEmailAddress] = useState("");
  const [password, setPassword] = useState("");
  const [rememberMe, setRememberMe] = useState(false);
  const navigate = useNavigate();

  // const [formData, setFormData] = useState({
  //   emailAddress: "",
  //   password: "",
  // });
  const handleSignIn = async (e) => {
    e.preventDefault();
    // Add your sign-in logic here

    const data = {
      email: emailAddress,
      password: password,
    };

    try {
      const response = await fetch(
        "https://server-mlm01.blockchainboostup.com/user/userInsert",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      if (!response.ok) {
        throw new Error("Authentication failed");
      }

      const responseData = await response.json();
      // Handle successful authentication, maybe store token in local storage or state
      console.log("Authentication successful", responseData);
      navigate("/");
    } catch (error) {
      // Handle error
      console.error("Error authenticating:", error.message);
    }
    console.log(
      "Signing in with:",
      emailAddress,
      password,
      "Remember Me:",
      rememberMe
    );
  };

  return (
    <div className="flex items-center justify-center h-screen w-screen bg-[#172B4D]">
      <form className="bg-white p-8 shadow-md rounded-md w-96">
        <div className="w-full flex flex-col justify-center items-center ">
          <img
            className="w-[100px]"
            src="https://demo.mlmreadymade.com/binary_investment_tron_deposit/images/logo/logo.png"
          />
          <h2 className="text-2xl font-semibold mb-4">SIGN IN</h2>
        </div>

        <div className="mb-4">
          <label
            htmlFor="emailAddress"
            className="block text-gray-600 text-sm font-medium"
          >
            EmailAddress
          </label>
          <input
            type="email"
            id="emailAddress"
            className="w-full mt-1 p-2 border rounded-md"
            placeholder="name"
            value={emailAddress}
            onChange={(e) => setEmailAddress(e.target.value)}
            required
          />
        </div>

        <div className="mb-6">
          <label
            htmlFor="password"
            className="block text-gray-600 text-sm font-medium"
          >
            Password:
          </label>
          <input
            type="password"
            id="password"
            className="w-full mt-1 p-2 border rounded-md"
            placeholder="********"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <div className="mb-4">
          <label htmlFor="rememberMe" className="flex items-center">
            <input
              type="checkbox"
              id="rememberMe"
              className="mr-2"
              checked={rememberMe}
              onChange={() => setRememberMe(!rememberMe)}
            />
            <span className="text-sm text-gray-600">Remember me</span>
          </label>
        </div>

        <div className="mb-4 ">
          <a href="#" className="text-sm text-blue-500 hover:underline">
            Forgot your password?
          </a>
        </div>

        <button
          type="submit"
          className="w-full bg-blue-500 text-white p-2 rounded-md hover:bg-blue-600"
          onClick={handleSignIn}
        >
          Sign In
        </button>
      </form>
    </div>
  );
};

export default SignInForm;
