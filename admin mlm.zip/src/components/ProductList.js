import React, { useEffect, useState } from "react";

import {
  Button,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import EditIcon from "@mui/icons-material/Edit";
import { Link } from "react-router-dom";

const ProductList = () => {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editedProductId, setEditedProductId] = useState(null);

  const handleEdit = (productId) => {
    // Logic to handle edit functionality
    console.log("Edit product with id:", productId);
    setEditedProductId(productId);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await fetch(
          "https://server-mlm01.blockchainboostup.com/product/"
        );
        const result = await response.json();
        setData(result);
      } catch (error) {
        setError(error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  // let tableData = data?.product;

  // const handleDelete = (productId) => {
  //   // Logic to handle delete functionality
  //   console.log(tableData, "4565");
  //   const updatedTableData = tableData.filter(
  //     (product) => product._id !== productId
  //   );
  //   console.log(updatedTableData, "4567");
  //   setData(updatedTableData);
  //   // tableData = data;
  //   console.log("Delete product with id:", productId);
  // };

  const deleteProduct = async (productId) => {
    try {
      const response = await fetch(
        `https://server-mlm01.blockchainboostup.com/product/${productId}`,
        {
          method: "DELETE",
        }
      );
      const result = await response.json();
      console.log(result, "474");
      if (!response.ok) {
        throw new Error("Failed to delete product");
      }
      // Remove the deleted product from the state
      console.log(data?.product);

      let res = data?.product?.filter((product) => product._id !== productId);
      setData(res);
      // tableData = res;
      console.log(`${productId} is deleted`);
      console.log(data, "00");
    } catch (error) {
      console.error("Error deleting product:", error.message);
    }
  };
  return (
    <div className="max-w-[375px] sm:max-w-full overflow-x-auto ">
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Product Id</TableCell>
              <TableCell>Image</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Category</TableCell>
              <TableCell>Qty</TableCell>
              <TableCell>Action</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {data?.product?.map((row, index) => (
              <TableRow key={index}>
                <TableCell>{row.itemId}</TableCell>
                <TableCell>
                  <img
                    className="w-40 sm:w-24 md:w-32 lg:w-40 xl:w-32"
                    src={`https://boostupmlm-project01.s3.ap-south-1.amazonaws.com/${row.photos[0]}`}
                  />
                </TableCell>
                <TableCell>{row?.itemName}</TableCell>
                <TableCell>{row?.categoryId?.categoryName}</TableCell>
                <TableCell>{row.quantityInStock}</TableCell>
                <TableCell>
                  <div className="space-x-2  flex  sm:flex-row ">
                    <Button
                      component={Link}
                      to="/editProduct"
                      onClick={() => handleEdit(row.itemId)}
                      startIcon={<EditIcon />}
                      variant="contained"
                      color="primary"
                    >
                      Edit
                    </Button>
                    <Button
                      onClick={() => deleteProduct(row._id)}
                      startIcon={<DeleteIcon />}
                      variant="contained"
                      color="error"
                    >
                      Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </div>
  );
};

export default ProductList;
