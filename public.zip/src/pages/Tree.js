import React from "react";
import OrgChartTree from "../components/Tree3";

const Tree = () => {
  return (
    <div>
      <OrgChartTree />
    </div>
  );
};

export default Tree;
