import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import { Form, Link } from "react-router-dom";
import { Button, InputLabel, MenuItem } from "@mui/material";
import Select from "@mui/material/Select";
import { Controller, useForm } from "react-hook-form";

const FilterForm = () => {
  const [value1, setValue1] = useState("");
  const handleChange1 = (event) => {
    setValue1(event.target.value);
  };
  const { handleSubmit, control } = useForm();

  const onSubmit = (data) => {
    setValue1(data);
    console.log(data);
    // Handle form submission logic here
  };
  return (
    <div>
      <div className="bg-white shadow-md rounded-md p-6 my-8">
        {/*  Input Fields */}
        <form
          onSubmit={handleSubmit(onSubmit)}
          className="flex mb-4 flex-wrap gap-4"
        >
          <Controller
            name="Enter Name"
            control={control}
            defaultValue=""
            render={({ field }) => <TextField {...field} label="Enter Name" />}
          />

          <Controller
            name="Enter Username"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <TextField {...field} label="Enter Username" />
            )}
          />

          <Controller
            name="Email"
            control={control}
            defaultValue=""
            render={({ field }) => <TextField {...field} label="Enter Email" />}
          />

          <Controller
            name="Sponser"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <TextField {...field} label="Enter Sponser" />
            )}
          />

          <Controller
            name="Mobile"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <TextField {...field} label="Enter Mobile" />
            )}
          />

          {/*  Dropdwon Fields */}
          <Controller
            name="status"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <Select {...field} labelId="status" label="Select a status">
                <MenuItem value="Active">Active</MenuItem>
                <MenuItem value="Inactive">Inactive</MenuItem>
              </Select>
            )}
          />

          <Controller
            name="userStatus"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <Select
                {...field}
                labelId="userStatus"
                label="Select a userStatus"
              >
                <MenuItem value="Block">Block</MenuItem>
                <MenuItem value="Unblock">Unblock</MenuItem>
              </Select>
            )}
          />

          <Controller
            name="num"
            control={control}
            defaultValue=""
            render={({ field }) => (
              <Select {...field} labelId="num" label="Select a num">
                <MenuItem value={10}>10</MenuItem>
                <MenuItem value={20}>20</MenuItem>
                <MenuItem value={30}>30</MenuItem>
                <MenuItem value={40}>40</MenuItem>
                <MenuItem value={50}>50</MenuItem>
              </Select>
            )}
          />

          <Button type="submit" variant="outlined">
            Fill
          </Button>

          <Button variant="contained">Reset</Button>

          <input
            type="submit"
            name="export_to_excel"
            className="border p-[4px_8px]"
            value="Export to excel"
          ></input>
        </form>
      </div>
    </div>
  );
};

export default FilterForm;
